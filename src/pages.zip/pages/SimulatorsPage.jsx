import { useEffect, useState } from "react";
import Header from "../components/Header";
import Footer from "../components/Footer";
import ScrollReveal from "../components/ScrollReveal";
import { Target, Shield } from "lucide-react";

const CATEGORY_ID = "a9946fcb-a184-4597-91c8-cff5f2ac084e";

const SimulatorsPage = () => {
  const [simulators, setSimulators] = useState([]);

  useEffect(() => {
    fetch("http://127.0.0.1:8000/api/products")
      .then((res) => res.json())
      .then((data) => {
        const filtered = data.filter(
          (item) => item.category_id === CATEGORY_ID
        );
        setSimulators(filtered);
      })
      .catch((err) => console.error(err));
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main>
        {/* HERO */}
        <section className="pt-28 pb-14 bg-gradient-to-b from-sand-dark/50 via-sand-dark/30 to-background relative overflow-hidden">
          <div className="absolute inset-0 opacity-40 pointer-events-none">
            <div className="absolute top-10 left-1/2 -translate-x-1/2 w-[500px] h-[500px] bg-brass-gold/10 blur-3xl rounded-full" />
          </div>

          <div className="container-width px-4 text-center max-w-2xl mx-auto relative z-10">
            <ScrollReveal>
              <div className="inline-flex items-center gap-3 mb-3">
                <span className="w-10 h-px bg-brass-gold" />
                <span className="text-brass-gold uppercase tracking-[0.25em] text-xs font-semibold">
                  Simulators & Training
                </span>
                <span className="w-10 h-px bg-brass-gold" />
              </div>

              <h1 className="text-3xl sm:text-4xl font-bold mt-3 mb-4 leading-tight text-foreground">
                Combat Training Systems
              </h1>

              <p className="text-sm sm:text-base text-muted-foreground leading-relaxed max-w-xl mx-auto">
                Realistic and cost-effective simulation platforms for modern
                combat readiness.
              </p>
            </ScrollReveal>
          </div>
        </section>

        {/* PRODUCTS */}
        <section className="section-padding bg-background">
          <div className="container-width space-y-16">
            {simulators.map((sim, index) => (
              <ScrollReveal key={sim.id}>
                <div
                  className={`grid lg:grid-cols-2 gap-8 lg:gap-12 items-center ${
                    index % 2 !== 0 ? "lg:[&>*:first-child]:order-2 lg:[&>*:last-child]:order-1" : ""
                  }`}
                >
                  {/* TEXT */}
                  <div className="space-y-4 max-w-lg">
                    <div className="inline-flex items-center gap-2 bg-defence-green/10 px-3 py-1.5 border border-defence-green/20 rounded-sm w-fit shadow-sm">
                      <Target className="w-3.5 h-3.5 text-defence-green" />
                      <span className="text-xs text-defence-green font-medium tracking-wide">
                        Simulator
                      </span>
                    </div>

                    <h2 className="text-3xl font-semibold leading-snug text-foreground">
                      {sim.name}
                    </h2>

                    <p className="text-base text-muted-foreground leading-7">
                      
                      {sim.description}
                    </p>

                    <ul className="space-y-2 text-sm text-muted-foreground pt-2">
                      {sim.specifications
                        ?.split("\n")
                        .map((item) => item.trim())
                        .filter(Boolean)
                        .map((item, i) => (
                          <li
                            key={i}
                            className="flex gap-2 items-start transition-transform duration-300 hover:translate-x-1"
                          >
                            <Shield className="w-3.5 h-3.5 text-defence-green mt-1 flex-shrink-0" />
                            <span>{item}</span>
                          </li>
                        ))}
                    </ul>
                  </div>

                  {/* IMAGES */}
                  <div className="flex justify-center">
                    <div
                      className={`grid ${
                        sim.images?.length > 1 ? "grid-cols-2" : "grid-cols-1"
                      } gap-3 w-full max-w-md`}
                    >
                      {sim.images?.slice(0, 2).map((img, i) => (
                        <div
                          key={i}
                          className="relative aspect-[4/3] overflow-hidden rounded-lg border border-gunmetal/10 bg-gradient-to-br from-white via-sand-dark/10 to-sand-dark/20 shadow-md group"
                        >
                          
                          <img
                            src={img}
                            alt={`${sim.name} ${i + 1}`}
                           className="w-full h-full object-cover"
                          />
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </ScrollReveal>
            ))}
          </div>
        </section>

        {/* WHY SECTION */}
        <section className="section-padding bg-gradient-to-b from-sand-dark/20 via-sand-dark/30 to-sand-dark/40">
          <div className="container-width max-w-2xl mx-auto text-center">
            <ScrollReveal>
              <div className="inline-flex items-center gap-3 mb-4">
                <span className="w-8 h-px bg-brass-gold" />
                <span className="text-brass-gold uppercase tracking-[0.22em] text-xs font-semibold">
                  Advantages
                </span>
                <span className="w-8 h-px bg-brass-gold" />
              </div>

              <h2 className="text-2xl font-semibold mb-6 text-foreground">
                Why Simulation Training?
              </h2>

              <ul className="space-y-3 text-sm text-left text-muted-foreground bg-white/40 backdrop-blur-sm border border-gunmetal/10 rounded-xl p-6 shadow-sm">
                {[
                  "100% indigenously developed system",
                  "Cost-effective alternative to live-fire training",
                  "Weather-independent indoor operation",
                  "Comprehensive performance tracking and scoring",
                  "Realistic weapon dynamics and recoil simulation",
                  "Customizable scenarios for mission-specific preparation",
                ].map((item, i) => (
                  <li
                    key={i}
                    className="flex gap-3 items-start transition-all duration-300 hover:translate-x-1 hover:text-foreground"
                  >
                    <Shield className="w-4 h-4 text-defence-green mt-1 flex-shrink-0" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </ScrollReveal>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default SimulatorsPage;